import {Post} from "../types/entities/Post";
import {Comment} from "../types/entities/Comment";
import { FirestoreCollections } from "../types/firestore";
import { IResBody } from "../types/api";
import { firestoreTimestamp } from "../utils/firestore-helpers";
import {User} from "../types/entities/User";
import {categories} from "../constants/categories";


export class PostsService {

  private db: FirestoreCollections;

  constructor(db: FirestoreCollections) {
    this.db = db;
  }

  async createPost(postData: Post): Promise<IResBody> {

    const postsQuerySnapshot = await this.db.posts.get();

    if (postsQuerySnapshot.empty){
      const postRef = this.db.posts.doc();
      await postRef.set({
        ...postData,
        voteCount: 0,
        createdAt: firestoreTimestamp.now(),
        updatedAt: firestoreTimestamp.now(),
      });

      return {
        status : 201,
        message: 'Post Created successfully!',
      }

    } else {
      return {
        status: 409,
        message: 'Post already exists',
      }
    }

  }

  async getPosts(): Promise<IResBody> {

    const posts: Post[] = [];

    const postsQuerySnapshot = await this.db.posts.get();

    for (const doc of postsQuerySnapshot.docs){
      posts.push({
        id: doc.id,
        ...doc.data(),
      })

    }

    return {
      status: 200,
      message: 'posts retrieved successfully!',
      data: posts
    }
  }

  async getPostById(postId: string): Promise<IResBody> {
    const postDoc = await this.db.posts.doc(postId).get();
    console.log(postDoc.data());
    return {
      status: 200,
      message: 'Users retrieved successfully!',
      data: {
        id: postId,
        ...postDoc.data()
      }
    }

  }

  async getAllPostsByUser(userId: string): Promise<IResBody> {
    const postsDoc = await this.db.posts.where('createdBy', '==', userId).get();

    return {
      status: 200,
      message: 'Users retrieved successfully!',
      data: {
        ...postsDoc
      }
    }
  }

  async getCategories(): Promise<IResBody> {
    return {
      status: 200,
      message: 'Categories retrieved successfully!',
      data: categories
    }
  }

  async addCommentToPost(postId: string, commentData: Comment): Promise<IResBody> {
    //Logic to add comment
    return {
      status: 200,
      message: 'Comment retrieved successfully!',
    }
  }

  async updatePostsById(postId: string, postData: User): Promise<IResBody> {
    const postDoc = await this.db.posts.doc(postId).get();

    const postRef = this.db.posts.doc(postId);
    await postRef.set({
      ...postDoc.data(),
      ...postData,
      updatedAt: firestoreTimestamp.now(),
    });

    return {
      status: 200,
      message: 'Users update successfully!',
    }

  }

}
