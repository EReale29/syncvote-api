export const categories = [
  {
    key: 'sports',
    label: 'Sports'
  },
  {
    key: 'video-games',
    label: 'Video Games'
  },
  {
    key: 'food',
    label: 'Food'
  },
  {
    key: 'film',
    label: 'Film'
  },
  {
    key: 'music',
    label: 'Music'
  },
  {
    key: 'technology',
    label: 'Technology'
  },
  {
    key: 'literature',
    label: 'Literature'
  },
  {
    key: 'art',
    label: 'Art'
  },
  {
    key: 'science',
    label: 'Science'
  },
  {
    key: 'fashion',
    label: 'Fashion'
  },
  {
    key: 'history',
    label: 'History'
  },
  {
    key: 'travel',
    label: 'Travel'
  },
  {
    key: 'health',
    label: 'Health'
  },
  {
    key: 'education',
    label: 'Education'
  },
  {
    key: 'business',
    label: 'Business'
  },
  {
    key: 'finance',
    label: 'Finance'
  },
  {
    key: 'nature',
    label: 'Nature'
  },
  {
    key: 'photography',
    label: 'Photography'
  },
  {
    key: 'politics',
    label: 'Politics'
  },
  {
    key: 'automotive',
    label: 'Automotive'
  },
  {
    key: 'architecture',
    label: 'Architecture'
  },
  {
    key: 'pets',
    label: 'Pets'
  },
  {
    key: 'gaming',
    label: 'Gaming'
  },
  {
    key: 'fitness',
    label: 'Fitness'
  },
  {
    key: 'psychology',
    label: 'Psychology'
  }
]
