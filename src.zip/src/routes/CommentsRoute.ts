import { Router } from 'express';
import { CommentController } from '../controllers';
import { validateCreateComment } from '../middlewares/dataValidator';

export class CommentsRoute {
  private commentController: CommentController;

  constructor(commentController: CommentController) {
    this.commentController = commentController;
  }

  createRouter(): Router {
    const router = Router();

    //Creation de commentaire
    router.post('/comments', validateCreateComment, this.commentController.createComment.bind(this.commentController));
    // -> AddComment
    // Recuperation des commentaire
    router.get('/comments', this.commentController.getComments.bind(this.commentController));
    router.get('/comments/:id', this.commentController.getCommentById.bind(this.commentController));
    // -> GetAllCommentsOfPost
    // Mise a jour du commentaire
    // -> UpdateComment
    // Suppression du commentaire
    // -> DeleteComments

    return router;
  }
}
