import { Router } from 'express';
import { PostController } from '../controllers';
import {
  validateCreatePost,
  validateUpdatePost
} from '../middlewares/dataValidator';
import authJwt from "../middlewares/authJwt";

export class PostsRoute {
  private postController: PostController;

  constructor(postController: PostController) {
    this.postController = postController;
  }

  createRouter(): Router {
    const router = Router();

    //Creation de post
    router.post('/posts', validateCreatePost, this.postController.createPost.bind(this.postController));
    //Affichage de post
    router.get('/posts', authJwt.verifyToken, this.postController.getPosts.bind(this.postController));
    router.get('/posts/:id', authJwt.verifyToken, this.postController.getPostById.bind(this.postController));
    router.get('/users/:userId/posts', authJwt.verifyToken, this.postController.getAllPostsByUser.bind(this.postController));
    router.get('/categories', this.postController.getCategories.bind(this.postController));
    //Mise a jour du post
    router.put('/posts/:id', validateUpdatePost, authJwt.verifyToken, this.postController.updatePostById.bind(this.postController));
    //Suppression du post
    // -> Delete post

    // A mettre a jour dans comments
    router.post('posts/:postId/comments', authJwt.verifyToken, this.postController.addCommentToPost.bind(this.postController));

    return router;
  }
}
