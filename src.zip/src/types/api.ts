export interface IResBody {
  status: number;
  message: string;
  data?: any;
}
